<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $fillable=['about','title1','paragraph1','title2','paragraph1','title3','paragraph3'];
}
