<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AboutCondition extends Model
{
    protected $fillable =['about','condition'];
}
