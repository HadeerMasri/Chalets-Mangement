<strong>{{ $user->name }}</strong>,
<br>
<p>{{ $user->email }}</p>

<p>تم تسجيل مستخدم جديد</p>
