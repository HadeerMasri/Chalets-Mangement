<strong>{{ $user->name }}</strong>,
<br>
<p>{{ $user->email }}</p>

<p>تم تسجيلك بنجاح.</p>
